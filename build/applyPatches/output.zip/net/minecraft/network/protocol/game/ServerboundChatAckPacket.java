package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;

public record ServerboundChatAckPacket(int f_244085_) implements Packet<ServerGamePacketListener> {
   public ServerboundChatAckPacket(FriendlyByteBuf p_242339_) {
      this(p_242339_.m_130242_());
   }

   public void m_5779_(FriendlyByteBuf p_242345_) {
      p_242345_.m_130130_(this.f_244085_);
   }

   public void m_5797_(ServerGamePacketListener p_242391_) {
      p_242391_.m_241885_(this);
   }
}