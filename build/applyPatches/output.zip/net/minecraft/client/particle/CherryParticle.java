package net.minecraft.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CherryParticle extends TextureSheetParticle {
   private static final float f_276642_ = 0.0025F;
   private static final int f_276664_ = 300;
   private static final int f_276480_ = 300;
   private static final float f_276422_ = 0.25F;
   private static final float f_276657_ = 2.0F;
   private float f_276609_;
   private final float f_276535_;
   private final float f_276513_;

   protected CherryParticle(ClientLevel p_277612_, double p_278010_, double p_277614_, double p_277673_, SpriteSet p_277465_) {
      super(p_277612_, p_278010_, p_277614_, p_277673_);
      this.m_108337_(p_277465_.m_5819_(this.f_107223_.m_188503_(12), 12));
      this.f_276609_ = (float)Math.toRadians(this.f_107223_.m_188499_() ? -30.0D : 30.0D);
      this.f_276535_ = this.f_107223_.m_188501_();
      this.f_276513_ = (float)Math.toRadians(this.f_107223_.m_188499_() ? -5.0D : 5.0D);
      this.f_107225_ = 300;
      this.f_107226_ = 7.5E-4F;
      float f = this.f_107223_.m_188499_() ? 0.05F : 0.075F;
      this.f_107663_ = f;
      this.m_107250_(f, f);
      this.f_172258_ = 1.0F;
   }

   public ParticleRenderType m_7556_() {
      return ParticleRenderType.f_107430_;
   }

   public void m_5989_() {
      this.f_107209_ = this.f_107212_;
      this.f_107210_ = this.f_107213_;
      this.f_107211_ = this.f_107214_;
      if (this.f_107225_-- <= 0) {
         this.m_107274_();
      }

      if (!this.f_107220_) {
         float f = (float)(300 - this.f_107225_);
         float f1 = Math.min(f / 300.0F, 1.0F);
         double d0 = Math.cos(Math.toRadians((double)(this.f_276535_ * 60.0F))) * 2.0D * Math.pow((double)f1, 1.25D);
         double d1 = Math.sin(Math.toRadians((double)(this.f_276535_ * 60.0F))) * 2.0D * Math.pow((double)f1, 1.25D);
         this.f_107215_ += d0 * (double)0.0025F;
         this.f_107217_ += d1 * (double)0.0025F;
         this.f_107216_ -= (double)this.f_107226_;
         this.f_276609_ += this.f_276513_ / 20.0F;
         this.f_107204_ = this.f_107231_;
         this.f_107231_ += this.f_276609_ / 20.0F;
         this.m_6257_(this.f_107215_, this.f_107216_, this.f_107217_);
         if (this.f_107218_ || this.f_107225_ < 299 && (this.f_107215_ == 0.0D || this.f_107217_ == 0.0D)) {
            this.m_107274_();
         }

         if (!this.f_107220_) {
            this.f_107215_ *= (double)this.f_172258_;
            this.f_107216_ *= (double)this.f_172258_;
            this.f_107217_ *= (double)this.f_172258_;
         }
      }
   }
}