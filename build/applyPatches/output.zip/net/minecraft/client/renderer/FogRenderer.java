package net.minecraft.client.renderer;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.shaders.FogShape;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.CubicSampler;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.material.FogType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class FogRenderer {
   private static final int f_172575_ = 96;
   private static final List<FogRenderer.MobEffectFogFunction> f_234164_ = Lists.newArrayList(new FogRenderer.BlindnessFogFunction(), new FogRenderer.DarknessFogFunction());
   public static final float f_172574_ = 5000.0F;
   private static float f_109010_;
   private static float f_109011_;
   private static float f_109012_;
   private static int f_109013_ = -1;
   private static int f_109014_ = -1;
   private static long f_109015_ = -1L;

   public static void m_109018_(Camera p_109019_, float p_109020_, ClientLevel p_109021_, int p_109022_, float p_109023_) {
      FogType fogtype = p_109019_.m_167685_();
      Entity entity = p_109019_.m_90592_();
      if (fogtype == FogType.WATER) {
         long i = Util.m_137550_();
         int j = p_109021_.m_204166_(BlockPos.m_274446_(p_109019_.m_90583_())).m_203334_().m_47561_();
         if (f_109015_ < 0L) {
            f_109013_ = j;
            f_109014_ = j;
            f_109015_ = i;
         }

         int k = f_109013_ >> 16 & 255;
         int l = f_109013_ >> 8 & 255;
         int i1 = f_109013_ & 255;
         int j1 = f_109014_ >> 16 & 255;
         int k1 = f_109014_ >> 8 & 255;
         int l1 = f_109014_ & 255;
         float f = Mth.m_14036_((float)(i - f_109015_) / 5000.0F, 0.0F, 1.0F);
         float f1 = Mth.m_14179_(f, (float)j1, (float)k);
         float f2 = Mth.m_14179_(f, (float)k1, (float)l);
         float f3 = Mth.m_14179_(f, (float)l1, (float)i1);
         f_109010_ = f1 / 255.0F;
         f_109011_ = f2 / 255.0F;
         f_109012_ = f3 / 255.0F;
         if (f_109013_ != j) {
            f_109013_ = j;
            f_109014_ = Mth.m_14143_(f1) << 16 | Mth.m_14143_(f2) << 8 | Mth.m_14143_(f3);
            f_109015_ = i;
         }
      } else if (fogtype == FogType.LAVA) {
         f_109010_ = 0.6F;
         f_109011_ = 0.1F;
         f_109012_ = 0.0F;
         f_109015_ = -1L;
      } else if (fogtype == FogType.POWDER_SNOW) {
         f_109010_ = 0.623F;
         f_109011_ = 0.734F;
         f_109012_ = 0.785F;
         f_109015_ = -1L;
         RenderSystem.clearColor(f_109010_, f_109011_, f_109012_, 0.0F);
      } else {
         float f4 = 0.25F + 0.75F * (float)p_109022_ / 32.0F;
         f4 = 1.0F - (float)Math.pow((double)f4, 0.25D);
         Vec3 vec3 = p_109021_.m_171660_(p_109019_.m_90583_(), p_109020_);
         float f6 = (float)vec3.f_82479_;
         float f8 = (float)vec3.f_82480_;
         float f10 = (float)vec3.f_82481_;
         float f11 = Mth.m_14036_(Mth.m_14089_(p_109021_.m_46942_(p_109020_) * ((float)Math.PI * 2F)) * 2.0F + 0.5F, 0.0F, 1.0F);
         BiomeManager biomemanager = p_109021_.m_7062_();
         Vec3 vec31 = p_109019_.m_90583_().m_82492_(2.0D, 2.0D, 2.0D).m_82490_(0.25D);
         Vec3 vec32 = CubicSampler.m_130038_(vec31, (p_109033_, p_109034_, p_109035_) -> {
            return p_109021_.m_104583_().m_5927_(Vec3.m_82501_(biomemanager.m_204210_(p_109033_, p_109034_, p_109035_).m_203334_().m_47539_()), f11);
         });
         f_109010_ = (float)vec32.m_7096_();
         f_109011_ = (float)vec32.m_7098_();
         f_109012_ = (float)vec32.m_7094_();
         if (p_109022_ >= 4) {
            float f12 = Mth.m_14031_(p_109021_.m_46490_(p_109020_)) > 0.0F ? -1.0F : 1.0F;
            Vector3f vector3f = new Vector3f(f12, 0.0F, 0.0F);
            float f16 = p_109019_.m_253058_().dot(vector3f);
            if (f16 < 0.0F) {
               f16 = 0.0F;
            }

            if (f16 > 0.0F) {
               float[] afloat = p_109021_.m_104583_().m_7518_(p_109021_.m_46942_(p_109020_), p_109020_);
               if (afloat != null) {
                  f16 *= afloat[3];
                  f_109010_ = f_109010_ * (1.0F - f16) + afloat[0] * f16;
                  f_109011_ = f_109011_ * (1.0F - f16) + afloat[1] * f16;
                  f_109012_ = f_109012_ * (1.0F - f16) + afloat[2] * f16;
               }
            }
         }

         f_109010_ += (f6 - f_109010_) * f4;
         f_109011_ += (f8 - f_109011_) * f4;
         f_109012_ += (f10 - f_109012_) * f4;
         float f13 = p_109021_.m_46722_(p_109020_);
         if (f13 > 0.0F) {
            float f14 = 1.0F - f13 * 0.5F;
            float f17 = 1.0F - f13 * 0.4F;
            f_109010_ *= f14;
            f_109011_ *= f14;
            f_109012_ *= f17;
         }

         float f15 = p_109021_.m_46661_(p_109020_);
         if (f15 > 0.0F) {
            float f18 = 1.0F - f15 * 0.5F;
            f_109010_ *= f18;
            f_109011_ *= f18;
            f_109012_ *= f18;
         }

         f_109015_ = -1L;
      }

      float f5 = ((float)p_109019_.m_90583_().f_82480_ - (float)p_109021_.m_141937_()) * p_109021_.m_6106_().m_205519_();
      FogRenderer.MobEffectFogFunction fogrenderer$mobeffectfogfunction = m_234165_(entity, p_109020_);
      if (fogrenderer$mobeffectfogfunction != null) {
         LivingEntity livingentity = (LivingEntity)entity;
         f5 = fogrenderer$mobeffectfogfunction.m_213936_(livingentity, livingentity.m_21124_(fogrenderer$mobeffectfogfunction.m_213948_()), f5, p_109020_);
      }

      if (f5 < 1.0F && fogtype != FogType.LAVA && fogtype != FogType.POWDER_SNOW) {
         if (f5 < 0.0F) {
            f5 = 0.0F;
         }

         f5 *= f5;
         f_109010_ *= f5;
         f_109011_ *= f5;
         f_109012_ *= f5;
      }

      if (p_109023_ > 0.0F) {
         f_109010_ = f_109010_ * (1.0F - p_109023_) + f_109010_ * 0.7F * p_109023_;
         f_109011_ = f_109011_ * (1.0F - p_109023_) + f_109011_ * 0.6F * p_109023_;
         f_109012_ = f_109012_ * (1.0F - p_109023_) + f_109012_ * 0.6F * p_109023_;
      }

      float f7;
      if (fogtype == FogType.WATER) {
         if (entity instanceof LocalPlayer) {
            f7 = ((LocalPlayer)entity).m_108639_();
         } else {
            f7 = 1.0F;
         }
      } else {
         label86: {
            if (entity instanceof LivingEntity) {
               LivingEntity livingentity1 = (LivingEntity)entity;
               if (livingentity1.m_21023_(MobEffects.f_19611_) && !livingentity1.m_21023_(MobEffects.f_216964_)) {
                  f7 = GameRenderer.m_109108_(livingentity1, p_109020_);
                  break label86;
               }
            }

            f7 = 0.0F;
         }
      }

      if (f_109010_ != 0.0F && f_109011_ != 0.0F && f_109012_ != 0.0F) {
         float f9 = Math.min(1.0F / f_109010_, Math.min(1.0F / f_109011_, 1.0F / f_109012_));
         f_109010_ = f_109010_ * (1.0F - f7) + f_109010_ * f9 * f7;
         f_109011_ = f_109011_ * (1.0F - f7) + f_109011_ * f9 * f7;
         f_109012_ = f_109012_ * (1.0F - f7) + f_109012_ * f9 * f7;
      }

      RenderSystem.clearColor(f_109010_, f_109011_, f_109012_, 0.0F);
   }

   public static void m_109017_() {
      RenderSystem.setShaderFogStart(Float.MAX_VALUE);
   }

   @Nullable
   private static FogRenderer.MobEffectFogFunction m_234165_(Entity p_234166_, float p_234167_) {
      if (p_234166_ instanceof LivingEntity livingentity) {
         return f_234164_.stream().filter((p_234171_) -> {
            return p_234171_.m_234205_(livingentity, p_234167_);
         }).findFirst().orElse((FogRenderer.MobEffectFogFunction)null);
      } else {
         return null;
      }
   }

   public static void m_234172_(Camera p_234173_, FogRenderer.FogMode p_234174_, float p_234175_, boolean p_234176_, float p_234177_) {
      FogType fogtype = p_234173_.m_167685_();
      Entity entity = p_234173_.m_90592_();
      FogRenderer.FogData fogrenderer$fogdata = new FogRenderer.FogData(p_234174_);
      FogRenderer.MobEffectFogFunction fogrenderer$mobeffectfogfunction = m_234165_(entity, p_234177_);
      if (fogtype == FogType.LAVA) {
         if (entity.m_5833_()) {
            fogrenderer$fogdata.f_234200_ = -8.0F;
            fogrenderer$fogdata.f_234201_ = p_234175_ * 0.5F;
         } else if (entity instanceof LivingEntity && ((LivingEntity)entity).m_21023_(MobEffects.f_19607_)) {
            fogrenderer$fogdata.f_234200_ = 0.0F;
            fogrenderer$fogdata.f_234201_ = 3.0F;
         } else {
            fogrenderer$fogdata.f_234200_ = 0.25F;
            fogrenderer$fogdata.f_234201_ = 1.0F;
         }
      } else if (fogtype == FogType.POWDER_SNOW) {
         if (entity.m_5833_()) {
            fogrenderer$fogdata.f_234200_ = -8.0F;
            fogrenderer$fogdata.f_234201_ = p_234175_ * 0.5F;
         } else {
            fogrenderer$fogdata.f_234200_ = 0.0F;
            fogrenderer$fogdata.f_234201_ = 2.0F;
         }
      } else if (fogrenderer$mobeffectfogfunction != null) {
         LivingEntity livingentity = (LivingEntity)entity;
         MobEffectInstance mobeffectinstance = livingentity.m_21124_(fogrenderer$mobeffectfogfunction.m_213948_());
         if (mobeffectinstance != null) {
            fogrenderer$mobeffectfogfunction.m_213725_(fogrenderer$fogdata, livingentity, mobeffectinstance, p_234175_, p_234177_);
         }
      } else if (fogtype == FogType.WATER) {
         fogrenderer$fogdata.f_234200_ = -8.0F;
         fogrenderer$fogdata.f_234201_ = 96.0F;
         if (entity instanceof LocalPlayer) {
            LocalPlayer localplayer = (LocalPlayer)entity;
            fogrenderer$fogdata.f_234201_ *= Math.max(0.25F, localplayer.m_108639_());
            Holder<Biome> holder = localplayer.m_9236_().m_204166_(localplayer.m_20183_());
            if (holder.m_203656_(BiomeTags.f_215802_)) {
               fogrenderer$fogdata.f_234201_ *= 0.85F;
            }
         }

         if (fogrenderer$fogdata.f_234201_ > p_234175_) {
            fogrenderer$fogdata.f_234201_ = p_234175_;
            fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
         }
      } else if (p_234176_) {
         fogrenderer$fogdata.f_234200_ = p_234175_ * 0.05F;
         fogrenderer$fogdata.f_234201_ = Math.min(p_234175_, 192.0F) * 0.5F;
      } else if (p_234174_ == FogRenderer.FogMode.FOG_SKY) {
         fogrenderer$fogdata.f_234200_ = 0.0F;
         fogrenderer$fogdata.f_234201_ = p_234175_;
         fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
      } else {
         float f = Mth.m_14036_(p_234175_ / 10.0F, 4.0F, 64.0F);
         fogrenderer$fogdata.f_234200_ = p_234175_ - f;
         fogrenderer$fogdata.f_234201_ = p_234175_;
         fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
      }

      RenderSystem.setShaderFogStart(fogrenderer$fogdata.f_234200_);
      RenderSystem.setShaderFogEnd(fogrenderer$fogdata.f_234201_);
      RenderSystem.setShaderFogShape(fogrenderer$fogdata.f_234202_);
   }

   public static void m_109036_() {
      RenderSystem.setShaderFogColor(f_109010_, f_109011_, f_109012_);
   }

   @OnlyIn(Dist.CLIENT)
   static class BlindnessFogFunction implements FogRenderer.MobEffectFogFunction {
      public MobEffect m_213948_() {
         return MobEffects.f_19610_;
      }

      public void m_213725_(FogRenderer.FogData p_234181_, LivingEntity p_234182_, MobEffectInstance p_234183_, float p_234184_, float p_234185_) {
         float f = p_234183_.m_267577_() ? 5.0F : Mth.m_14179_(Math.min(1.0F, (float)p_234183_.m_19557_() / 20.0F), p_234184_, 5.0F);
         if (p_234181_.f_234199_ == FogRenderer.FogMode.FOG_SKY) {
            p_234181_.f_234200_ = 0.0F;
            p_234181_.f_234201_ = f * 0.8F;
         } else {
            p_234181_.f_234200_ = f * 0.25F;
            p_234181_.f_234201_ = f;
         }

      }
   }

   @OnlyIn(Dist.CLIENT)
   static class DarknessFogFunction implements FogRenderer.MobEffectFogFunction {
      public MobEffect m_213948_() {
         return MobEffects.f_216964_;
      }

      public void m_213725_(FogRenderer.FogData p_234194_, LivingEntity p_234195_, MobEffectInstance p_234196_, float p_234197_, float p_234198_) {
         if (!p_234196_.m_216895_().isEmpty()) {
            float f = Mth.m_14179_(p_234196_.m_216895_().get().m_238413_(p_234195_, p_234198_), p_234197_, 15.0F);
            p_234194_.f_234200_ = p_234194_.f_234199_ == FogRenderer.FogMode.FOG_SKY ? 0.0F : f * 0.75F;
            p_234194_.f_234201_ = f;
         }
      }

      public float m_213936_(LivingEntity p_234189_, MobEffectInstance p_234190_, float p_234191_, float p_234192_) {
         return p_234190_.m_216895_().isEmpty() ? 0.0F : 1.0F - p_234190_.m_216895_().get().m_238413_(p_234189_, p_234192_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   static class FogData {
      public final FogRenderer.FogMode f_234199_;
      public float f_234200_;
      public float f_234201_;
      public FogShape f_234202_ = FogShape.SPHERE;

      public FogData(FogRenderer.FogMode p_234204_) {
         this.f_234199_ = p_234204_;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static enum FogMode {
      FOG_SKY,
      FOG_TERRAIN;
   }

   @OnlyIn(Dist.CLIENT)
   interface MobEffectFogFunction {
      MobEffect m_213948_();

      void m_213725_(FogRenderer.FogData p_234212_, LivingEntity p_234213_, MobEffectInstance p_234214_, float p_234215_, float p_234216_);

      default boolean m_234205_(LivingEntity p_234206_, float p_234207_) {
         return p_234206_.m_21023_(this.m_213948_());
      }

      default float m_213936_(LivingEntity p_234208_, MobEffectInstance p_234209_, float p_234210_, float p_234211_) {
         MobEffectInstance mobeffectinstance = p_234208_.m_21124_(this.m_213948_());
         if (mobeffectinstance != null) {
            if (mobeffectinstance.m_267633_(19)) {
               p_234210_ = 1.0F - (float)mobeffectinstance.m_19557_() / 20.0F;
            } else {
               p_234210_ = 0.0F;
            }
         }

         return p_234210_;
      }
   }
}