package net.minecraft.world.level.block;

import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;
import net.minecraft.world.level.block.state.properties.DirectionProperty;

public class CarvedPumpkinBlock extends HorizontalDirectionalBlock {
   public static final DirectionProperty f_51367_ = HorizontalDirectionalBlock.f_54117_;
   @Nullable
   private BlockPattern f_51368_;
   @Nullable
   private BlockPattern f_51369_;
   @Nullable
   private BlockPattern f_51370_;
   @Nullable
   private BlockPattern f_51371_;
   private static final Predicate<BlockState> f_51372_ = (p_51396_) -> {
      return p_51396_ != null && (p_51396_.m_60713_(Blocks.f_50143_) || p_51396_.m_60713_(Blocks.f_50144_));
   };

   protected CarvedPumpkinBlock(BlockBehaviour.Properties p_51375_) {
      super(p_51375_);
      this.m_49959_(this.f_49792_.m_61090_().m_61124_(f_51367_, Direction.NORTH));
   }

   public void m_6807_(BlockState p_51387_, Level p_51388_, BlockPos p_51389_, BlockState p_51390_, boolean p_51391_) {
      if (!p_51390_.m_60713_(p_51387_.m_60734_())) {
         this.m_51378_(p_51388_, p_51389_);
      }
   }

   public boolean m_51381_(LevelReader p_51382_, BlockPos p_51383_) {
      return this.m_51392_().m_61184_(p_51382_, p_51383_) != null || this.m_51394_().m_61184_(p_51382_, p_51383_) != null;
   }

   private void m_51378_(Level p_51379_, BlockPos p_51380_) {
      BlockPattern.BlockPatternMatch blockpattern$blockpatternmatch = this.m_51393_().m_61184_(p_51379_, p_51380_);
      if (blockpattern$blockpatternmatch != null) {
         SnowGolem snowgolem = EntityType.f_20528_.m_20615_(p_51379_);
         if (snowgolem != null) {
            m_245952_(p_51379_, blockpattern$blockpatternmatch, snowgolem, blockpattern$blockpatternmatch.m_61229_(0, 2, 0).m_61176_());
         }
      } else {
         BlockPattern.BlockPatternMatch blockpattern$blockpatternmatch1 = this.m_51397_().m_61184_(p_51379_, p_51380_);
         if (blockpattern$blockpatternmatch1 != null) {
            IronGolem irongolem = EntityType.f_20460_.m_20615_(p_51379_);
            if (irongolem != null) {
               irongolem.m_28887_(true);
               m_245952_(p_51379_, blockpattern$blockpatternmatch1, irongolem, blockpattern$blockpatternmatch1.m_61229_(1, 2, 0).m_61176_());
            }
         }
      }

   }

   private static void m_245952_(Level p_249110_, BlockPattern.BlockPatternMatch p_251293_, Entity p_251251_, BlockPos p_251189_) {
      m_245585_(p_249110_, p_251293_);
      p_251251_.m_7678_((double)p_251189_.m_123341_() + 0.5D, (double)p_251189_.m_123342_() + 0.05D, (double)p_251189_.m_123343_() + 0.5D, 0.0F, 0.0F);
      p_249110_.m_7967_(p_251251_);

      for(ServerPlayer serverplayer : p_249110_.m_45976_(ServerPlayer.class, p_251251_.m_20191_().m_82400_(5.0D))) {
         CriteriaTriggers.f_10580_.m_68256_(serverplayer, p_251251_);
      }

      m_246758_(p_249110_, p_251293_);
   }

   public static void m_245585_(Level p_249604_, BlockPattern.BlockPatternMatch p_251190_) {
      for(int i = 0; i < p_251190_.m_155970_(); ++i) {
         for(int j = 0; j < p_251190_.m_155971_(); ++j) {
            BlockInWorld blockinworld = p_251190_.m_61229_(i, j, 0);
            p_249604_.m_7731_(blockinworld.m_61176_(), Blocks.f_50016_.m_49966_(), 2);
            p_249604_.m_46796_(2001, blockinworld.m_61176_(), Block.m_49956_(blockinworld.m_61168_()));
         }
      }

   }

   public static void m_246758_(Level p_248711_, BlockPattern.BlockPatternMatch p_251935_) {
      for(int i = 0; i < p_251935_.m_155970_(); ++i) {
         for(int j = 0; j < p_251935_.m_155971_(); ++j) {
            BlockInWorld blockinworld = p_251935_.m_61229_(i, j, 0);
            p_248711_.m_6289_(blockinworld.m_61176_(), Blocks.f_50016_);
         }
      }

   }

   public BlockState m_5573_(BlockPlaceContext p_51377_) {
      return this.m_49966_().m_61124_(f_51367_, p_51377_.m_8125_().m_122424_());
   }

   protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_51385_) {
      p_51385_.m_61104_(f_51367_);
   }

   private BlockPattern m_51392_() {
      if (this.f_51368_ == null) {
         this.f_51368_ = BlockPatternBuilder.m_61243_().m_61247_(" ", "#", "#").m_61244_('#', BlockInWorld.m_61169_(BlockStatePredicate.m_61287_(Blocks.f_50127_))).m_61249_();
      }

      return this.f_51368_;
   }

   private BlockPattern m_51393_() {
      if (this.f_51369_ == null) {
         this.f_51369_ = BlockPatternBuilder.m_61243_().m_61247_("^", "#", "#").m_61244_('^', BlockInWorld.m_61169_(f_51372_)).m_61244_('#', BlockInWorld.m_61169_(BlockStatePredicate.m_61287_(Blocks.f_50127_))).m_61249_();
      }

      return this.f_51369_;
   }

   private BlockPattern m_51394_() {
      if (this.f_51370_ == null) {
         this.f_51370_ = BlockPatternBuilder.m_61243_().m_61247_("~ ~", "###", "~#~").m_61244_('#', BlockInWorld.m_61169_(BlockStatePredicate.m_61287_(Blocks.f_50075_))).m_61244_('~', (p_284869_) -> {
            return p_284869_.m_61168_().m_60795_();
         }).m_61249_();
      }

      return this.f_51370_;
   }

   private BlockPattern m_51397_() {
      if (this.f_51371_ == null) {
         this.f_51371_ = BlockPatternBuilder.m_61243_().m_61247_("~^~", "###", "~#~").m_61244_('^', BlockInWorld.m_61169_(f_51372_)).m_61244_('#', BlockInWorld.m_61169_(BlockStatePredicate.m_61287_(Blocks.f_50075_))).m_61244_('~', (p_284868_) -> {
            return p_284868_.m_61168_().m_60795_();
         }).m_61249_();
      }

      return this.f_51371_;
   }
}