package net.minecraft.world.entity.npc;

import net.minecraft.world.entity.VariantHolder;

public interface VillagerDataHolder extends VariantHolder<VillagerType> {
   VillagerData m_7141_();

   void m_34375_(VillagerData p_150027_);

   default VillagerType m_28554_() {
      return this.m_7141_().m_35560_();
   }

   default void m_28464_(VillagerType p_262647_) {
      this.m_34375_(this.m_7141_().m_35567_(p_262647_));
   }
}