package net.minecraft.network.protocol.game;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.resources.ResourceLocation;

public record ClientboundUpdateEnabledFeaturesPacket(Set<ResourceLocation> f_244610_) implements Packet<ClientGamePacketListener> {
   public ClientboundUpdateEnabledFeaturesPacket(FriendlyByteBuf p_250545_) {
      this(p_250545_.<ResourceLocation, Set<ResourceLocation>>m_236838_(HashSet::new, FriendlyByteBuf::m_130281_));
   }

   public void m_5779_(FriendlyByteBuf p_251972_) {
      p_251972_.m_236828_(this.f_244610_, FriendlyByteBuf::m_130085_);
   }

   public void m_5797_(ClientGamePacketListener p_250317_) {
      p_250317_.m_241155_(this);
   }
}
