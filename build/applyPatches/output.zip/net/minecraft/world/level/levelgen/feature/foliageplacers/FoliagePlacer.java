package net.minecraft.world.level.levelgen.feature.foliageplacers;

import com.mojang.datafixers.Products;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.world.level.LevelSimulatedReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.feature.TreeFeature;
import net.minecraft.world.level.levelgen.feature.configurations.TreeConfiguration;
import net.minecraft.world.level.material.Fluids;

public abstract class FoliagePlacer {
   public static final Codec<FoliagePlacer> f_68519_ = BuiltInRegistries.f_256861_.m_194605_().dispatch(FoliagePlacer::m_5897_, FoliagePlacerType::m_68604_);
   protected final IntProvider f_68520_;
   protected final IntProvider f_68521_;

   protected static <P extends FoliagePlacer> Products.P2<RecordCodecBuilder.Mu<P>, IntProvider, IntProvider> m_68573_(RecordCodecBuilder.Instance<P> p_68574_) {
      return p_68574_.group(IntProvider.m_146545_(0, 16).fieldOf("radius").forGetter((p_161449_) -> {
         return p_161449_.f_68520_;
      }), IntProvider.m_146545_(0, 16).fieldOf("offset").forGetter((p_161447_) -> {
         return p_161447_.f_68521_;
      }));
   }

   public FoliagePlacer(IntProvider p_161411_, IntProvider p_161412_) {
      this.f_68520_ = p_161411_;
      this.f_68521_ = p_161412_;
   }

   protected abstract FoliagePlacerType<?> m_5897_();

   public void m_271927_(LevelSimulatedReader p_273526_, FoliagePlacer.FoliageSetter p_273018_, RandomSource p_273425_, TreeConfiguration p_273138_, int p_273282_, FoliagePlacer.FoliageAttachment p_272944_, int p_272930_, int p_272727_) {
      this.m_213633_(p_273526_, p_273018_, p_273425_, p_273138_, p_273282_, p_272944_, p_272930_, p_272727_, this.m_225591_(p_273425_));
   }

   protected abstract void m_213633_(LevelSimulatedReader p_225613_, FoliagePlacer.FoliageSetter p_273598_, RandomSource p_225615_, TreeConfiguration p_225616_, int p_225617_, FoliagePlacer.FoliageAttachment p_225618_, int p_225619_, int p_225620_, int p_225621_);

   public abstract int m_214116_(RandomSource p_225601_, int p_225602_, TreeConfiguration p_225603_);

   public int m_214117_(RandomSource p_225593_, int p_225594_) {
      return this.f_68520_.m_214085_(p_225593_);
   }

   private int m_225591_(RandomSource p_225592_) {
      return this.f_68521_.m_214085_(p_225592_);
   }

   protected abstract boolean m_214203_(RandomSource p_225595_, int p_225596_, int p_225597_, int p_225598_, int p_225599_, boolean p_225600_);

   protected boolean m_214202_(RandomSource p_225639_, int p_225640_, int p_225641_, int p_225642_, int p_225643_, boolean p_225644_) {
      int i;
      int j;
      if (p_225644_) {
         i = Math.min(Math.abs(p_225640_), Math.abs(p_225640_ - 1));
         j = Math.min(Math.abs(p_225642_), Math.abs(p_225642_ - 1));
      } else {
         i = Math.abs(p_225640_);
         j = Math.abs(p_225642_);
      }

      return this.m_214203_(p_225639_, i, p_225641_, j, p_225643_, p_225644_);
   }

   protected void m_225628_(LevelSimulatedReader p_225629_, FoliagePlacer.FoliageSetter p_272772_, RandomSource p_225631_, TreeConfiguration p_225632_, BlockPos p_225633_, int p_225634_, int p_225635_, boolean p_225636_) {
      int i = p_225636_ ? 1 : 0;
      BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos();

      for(int j = -p_225634_; j <= p_225634_ + i; ++j) {
         for(int k = -p_225634_; k <= p_225634_ + i; ++k) {
            if (!this.m_214202_(p_225631_, j, p_225635_, k, p_225634_, p_225636_)) {
               blockpos$mutableblockpos.m_122154_(p_225633_, j, p_225635_, k);
               m_272253_(p_225629_, p_272772_, p_225631_, p_225632_, blockpos$mutableblockpos);
            }
         }
      }

   }

   protected final void m_272160_(LevelSimulatedReader p_273087_, FoliagePlacer.FoliageSetter p_273225_, RandomSource p_272629_, TreeConfiguration p_272885_, BlockPos p_273412_, int p_272712_, int p_272656_, boolean p_272689_, float p_273464_, float p_273068_) {
      this.m_225628_(p_273087_, p_273225_, p_272629_, p_272885_, p_273412_, p_272712_, p_272656_, p_272689_);
      int i = p_272689_ ? 1 : 0;
      BlockPos blockpos = p_273412_.m_7495_();
      BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos();

      for(Direction direction : Direction.Plane.HORIZONTAL) {
         Direction direction1 = direction.m_122427_();
         int j = direction1.m_122421_() == Direction.AxisDirection.POSITIVE ? p_272712_ + i : p_272712_;
         blockpos$mutableblockpos.m_122154_(p_273412_, 0, p_272656_ - 1, 0).m_122175_(direction1, j).m_122175_(direction, -p_272712_);
         int k = -p_272712_;

         while(k < p_272712_ + i) {
            boolean flag = p_273225_.m_271808_(blockpos$mutableblockpos.m_122173_(Direction.UP));
            blockpos$mutableblockpos.m_122173_(Direction.DOWN);
            if (flag && m_277091_(p_273087_, p_273225_, p_272629_, p_272885_, p_273464_, blockpos, blockpos$mutableblockpos)) {
               blockpos$mutableblockpos.m_122173_(Direction.DOWN);
               m_277091_(p_273087_, p_273225_, p_272629_, p_272885_, p_273068_, blockpos, blockpos$mutableblockpos);
               blockpos$mutableblockpos.m_122173_(Direction.UP);
            }

            ++k;
            blockpos$mutableblockpos.m_122173_(direction);
         }
      }

   }

   private static boolean m_277091_(LevelSimulatedReader p_277577_, FoliagePlacer.FoliageSetter p_277449_, RandomSource p_277966_, TreeConfiguration p_277897_, float p_277979_, BlockPos p_277833_, BlockPos.MutableBlockPos p_277567_) {
      if (p_277567_.m_123333_(p_277833_) >= 7) {
         return false;
      } else {
         return p_277966_.m_188501_() > p_277979_ ? false : m_272253_(p_277577_, p_277449_, p_277966_, p_277897_, p_277567_);
      }
   }

   protected static boolean m_272253_(LevelSimulatedReader p_273596_, FoliagePlacer.FoliageSetter p_273054_, RandomSource p_272977_, TreeConfiguration p_273040_, BlockPos p_273406_) {
      if (!TreeFeature.m_67272_(p_273596_, p_273406_)) {
         return false;
      } else {
         BlockState blockstate = p_273040_.f_161213_.m_213972_(p_272977_, p_273406_);
         if (blockstate.m_61138_(BlockStateProperties.f_61362_)) {
            blockstate = blockstate.m_61124_(BlockStateProperties.f_61362_, Boolean.valueOf(p_273596_.m_142433_(p_273406_, (p_225638_) -> {
               return p_225638_.m_164512_(Fluids.f_76193_);
            })));
         }

         p_273054_.m_271838_(p_273406_, blockstate);
         return true;
      }
   }

   public static final class FoliageAttachment {
      private final BlockPos f_161450_;
      private final int f_68582_;
      private final boolean f_68583_;

      public FoliageAttachment(BlockPos p_68585_, int p_68586_, boolean p_68587_) {
         this.f_161450_ = p_68585_;
         this.f_68582_ = p_68586_;
         this.f_68583_ = p_68587_;
      }

      public BlockPos m_161451_() {
         return this.f_161450_;
      }

      public int m_68589_() {
         return this.f_68582_;
      }

      public boolean m_68590_() {
         return this.f_68583_;
      }
   }

   public interface FoliageSetter {
      void m_271838_(BlockPos p_273742_, BlockState p_273780_);

      boolean m_271808_(BlockPos p_273118_);
   }
}