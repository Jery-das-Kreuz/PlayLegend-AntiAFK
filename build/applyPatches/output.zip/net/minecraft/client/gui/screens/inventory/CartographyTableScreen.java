package net.minecraft.client.gui.screens.inventory;

import javax.annotation.Nullable;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.CartographyTableMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CartographyTableScreen extends AbstractContainerScreen<CartographyTableMenu> {
   private static final ResourceLocation f_98346_ = new ResourceLocation("textures/gui/container/cartography_table.png");

   public CartographyTableScreen(CartographyTableMenu p_98349_, Inventory p_98350_, Component p_98351_) {
      super(p_98349_, p_98350_, p_98351_);
      this.f_97729_ -= 2;
   }

   public void m_88315_(GuiGraphics p_281331_, int p_281706_, int p_282996_, float p_283037_) {
      super.m_88315_(p_281331_, p_281706_, p_282996_, p_283037_);
      this.m_280072_(p_281331_, p_281706_, p_282996_);
   }

   protected void m_7286_(GuiGraphics p_282101_, float p_282697_, int p_282380_, int p_282327_) {
      this.m_280273_(p_282101_);
      int i = this.f_97735_;
      int j = this.f_97736_;
      p_282101_.m_280218_(f_98346_, i, j, 0, 0, this.f_97726_, this.f_97727_);
      ItemStack itemstack = this.f_97732_.m_38853_(1).m_7993_();
      boolean flag = itemstack.m_150930_(Items.f_42676_);
      boolean flag1 = itemstack.m_150930_(Items.f_42516_);
      boolean flag2 = itemstack.m_150930_(Items.f_42027_);
      ItemStack itemstack1 = this.f_97732_.m_38853_(0).m_7993_();
      boolean flag3 = false;
      Integer integer;
      MapItemSavedData mapitemsaveddata;
      if (itemstack1.m_150930_(Items.f_42573_)) {
         integer = MapItem.m_151131_(itemstack1);
         mapitemsaveddata = MapItem.m_151128_(integer, this.f_96541_.f_91073_);
         if (mapitemsaveddata != null) {
            if (mapitemsaveddata.f_77892_) {
               flag3 = true;
               if (flag1 || flag2) {
                  p_282101_.m_280218_(f_98346_, i + 35, j + 31, this.f_97726_ + 50, 132, 28, 21);
               }
            }

            if (flag1 && mapitemsaveddata.f_77890_ >= 4) {
               flag3 = true;
               p_282101_.m_280218_(f_98346_, i + 35, j + 31, this.f_97726_ + 50, 132, 28, 21);
            }
         }
      } else {
         integer = null;
         mapitemsaveddata = null;
      }

      this.m_280549_(p_282101_, integer, mapitemsaveddata, flag, flag1, flag2, flag3);
   }

   private void m_280549_(GuiGraphics p_282167_, @Nullable Integer p_282064_, @Nullable MapItemSavedData p_282045_, boolean p_282086_, boolean p_283531_, boolean p_282645_, boolean p_281646_) {
      int i = this.f_97735_;
      int j = this.f_97736_;
      if (p_283531_ && !p_281646_) {
         p_282167_.m_280218_(f_98346_, i + 67, j + 13, this.f_97726_, 66, 66, 66);
         this.m_280090_(p_282167_, p_282064_, p_282045_, i + 85, j + 31, 0.226F);
      } else if (p_282086_) {
         p_282167_.m_280218_(f_98346_, i + 67 + 16, j + 13, this.f_97726_, 132, 50, 66);
         this.m_280090_(p_282167_, p_282064_, p_282045_, i + 86, j + 16, 0.34F);
         p_282167_.m_280168_().m_85836_();
         p_282167_.m_280168_().m_252880_(0.0F, 0.0F, 1.0F);
         p_282167_.m_280218_(f_98346_, i + 67, j + 13 + 16, this.f_97726_, 132, 50, 66);
         this.m_280090_(p_282167_, p_282064_, p_282045_, i + 70, j + 32, 0.34F);
         p_282167_.m_280168_().m_85849_();
      } else if (p_282645_) {
         p_282167_.m_280218_(f_98346_, i + 67, j + 13, this.f_97726_, 0, 66, 66);
         this.m_280090_(p_282167_, p_282064_, p_282045_, i + 71, j + 17, 0.45F);
         p_282167_.m_280168_().m_85836_();
         p_282167_.m_280168_().m_252880_(0.0F, 0.0F, 1.0F);
         p_282167_.m_280218_(f_98346_, i + 66, j + 12, 0, this.f_97727_, 66, 66);
         p_282167_.m_280168_().m_85849_();
      } else {
         p_282167_.m_280218_(f_98346_, i + 67, j + 13, this.f_97726_, 0, 66, 66);
         this.m_280090_(p_282167_, p_282064_, p_282045_, i + 71, j + 17, 0.45F);
      }

   }

   private void m_280090_(GuiGraphics p_282298_, @Nullable Integer p_281648_, @Nullable MapItemSavedData p_282897_, int p_281632_, int p_282115_, float p_283388_) {
      if (p_281648_ != null && p_282897_ != null) {
         p_282298_.m_280168_().m_85836_();
         p_282298_.m_280168_().m_252880_((float)p_281632_, (float)p_282115_, 1.0F);
         p_282298_.m_280168_().m_85841_(p_283388_, p_283388_, 1.0F);
         this.f_96541_.f_91063_.m_109151_().m_168771_(p_282298_.m_280168_(), p_282298_.m_280091_(), p_281648_, p_282897_, true, 15728880);
         p_282298_.m_280262_();
         p_282298_.m_280168_().m_85849_();
      }

   }
}