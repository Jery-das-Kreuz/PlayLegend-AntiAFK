package net.minecraft.world.entity;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.world.level.EntityGetter;

public interface OwnableEntity {
   @Nullable
   UUID m_21805_();

   EntityGetter m_9236_();

   @Nullable
   default LivingEntity m_269323_() {
      UUID uuid = this.m_21805_();
      return uuid == null ? null : this.m_9236_().m_46003_(uuid);
   }
}