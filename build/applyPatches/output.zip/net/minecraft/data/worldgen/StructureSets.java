package net.minecraft.data.worldgen;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.structure.BuiltinStructureSets;
import net.minecraft.world.level.levelgen.structure.BuiltinStructures;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.placement.ConcentricRingsStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadType;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacement;

public interface StructureSets {
   static void m_255117_(BootstapContext<StructureSet> p_256148_) {
      HolderGetter<Structure> holdergetter = p_256148_.m_255420_(Registries.f_256944_);
      HolderGetter<Biome> holdergetter1 = p_256148_.m_255420_(Registries.f_256952_);
      Holder.Reference<StructureSet> reference = p_256148_.m_255272_(BuiltinStructureSets.f_209820_, new StructureSet(List.of(StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209864_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209865_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209866_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209867_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209868_))), new RandomSpreadStructurePlacement(34, 8, RandomSpreadType.LINEAR, 10387312)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209821_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209850_), new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357617)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209822_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209851_), new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357618)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209823_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209849_), new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357619)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209824_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209854_), new RandomSpreadStructurePlacement(32, 8, RandomSpreadType.LINEAR, 14357620)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209825_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209845_), new RandomSpreadStructurePlacement(Vec3i.f_123288_, StructurePlacement.FrequencyReductionMethod.LEGACY_TYPE_1, 0.2F, 165745296, Optional.of(new StructurePlacement.ExclusionZone(reference, 10)), 32, 8, RandomSpreadType.LINEAR)));
      p_256148_.m_255272_(BuiltinStructureSets.f_226491_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_226492_), new RandomSpreadStructurePlacement(24, 8, RandomSpreadType.LINEAR, 20083232)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209826_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209856_), new RandomSpreadStructurePlacement(32, 5, RandomSpreadType.TRIANGULAR, 10387313)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209827_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209848_), new RandomSpreadStructurePlacement(80, 20, RandomSpreadType.TRIANGULAR, 10387319)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209828_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209862_), new RandomSpreadStructurePlacement(new Vec3i(9, 0, 9), StructurePlacement.FrequencyReductionMethod.LEGACY_TYPE_2, 0.01F, 0, Optional.empty(), 1, 0, RandomSpreadType.LINEAR)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209829_, new StructureSet(List.of(StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209846_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209847_))), new RandomSpreadStructurePlacement(Vec3i.f_123288_, StructurePlacement.FrequencyReductionMethod.LEGACY_TYPE_3, 0.004F, 0, Optional.empty(), 1, 0, RandomSpreadType.LINEAR)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209830_, new StructureSet(List.of(StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209869_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209870_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209840_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209841_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209842_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209843_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209844_))), new RandomSpreadStructurePlacement(40, 15, RandomSpreadType.LINEAR, 34222645)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209831_, new StructureSet(List.of(StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209852_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209853_))), new RandomSpreadStructurePlacement(24, 4, RandomSpreadType.LINEAR, 165745295)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209832_, new StructureSet(List.of(StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209857_)), StructureSet.m_210015_(holdergetter.m_255043_(BuiltinStructures.f_209858_))), new RandomSpreadStructurePlacement(20, 8, RandomSpreadType.LINEAR, 14357621)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209833_, new StructureSet(List.of(StructureSet.m_210017_(holdergetter.m_255043_(BuiltinStructures.f_209859_), 2), StructureSet.m_210017_(holdergetter.m_255043_(BuiltinStructures.f_209863_), 3)), new RandomSpreadStructurePlacement(27, 4, RandomSpreadType.LINEAR, 30084232)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209834_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209860_), new RandomSpreadStructurePlacement(2, 1, RandomSpreadType.LINEAR, 14357921)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209835_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209861_), new RandomSpreadStructurePlacement(20, 11, RandomSpreadType.TRIANGULAR, 10387313)));
      p_256148_.m_255272_(BuiltinStructureSets.f_209836_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_209855_), new ConcentricRingsStructurePlacement(32, 3, 128, holdergetter1.m_254956_(BiomeTags.f_215819_))));
      p_256148_.m_255272_(BuiltinStructureSets.f_276475_, new StructureSet(holdergetter.m_255043_(BuiltinStructures.f_276588_), new RandomSpreadStructurePlacement(34, 8, RandomSpreadType.LINEAR, 83469867)));
   }
}