package net.minecraft.world.level.lighting;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.DataLayer;

public interface LayerLightEventListener extends LightEventListener {
   @Nullable
   DataLayer m_8079_(SectionPos p_75709_);

   int m_7768_(BlockPos p_75710_);

   public static enum DummyLightLayerEventListener implements LayerLightEventListener {
      INSTANCE;

      @Nullable
      public DataLayer m_8079_(SectionPos p_75718_) {
         return null;
      }

      public int m_7768_(BlockPos p_75723_) {
         return 0;
      }

      public void m_7174_(BlockPos p_164434_) {
      }

      public boolean m_75808_() {
         return false;
      }

      public int m_9323_() {
         return 0;
      }

      public void m_6191_(SectionPos p_75720_, boolean p_75721_) {
      }

      public void m_9335_(ChunkPos p_164431_, boolean p_164432_) {
      }

      public void m_142519_(ChunkPos p_285209_) {
      }
   }
}