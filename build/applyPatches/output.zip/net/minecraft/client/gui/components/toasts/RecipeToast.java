package net.minecraft.client.gui.components.toasts;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RecipeToast implements Toast {
   private static final long f_169076_ = 5000L;
   private static final Component f_94803_ = Component.m_237115_("recipe.toast.title");
   private static final Component f_94804_ = Component.m_237115_("recipe.toast.description");
   private final List<Recipe<?>> f_94805_ = Lists.newArrayList();
   private long f_94806_;
   private boolean f_94807_;

   public RecipeToast(Recipe<?> p_94810_) {
      this.f_94805_.add(p_94810_);
   }

   public Toast.Visibility m_7172_(GuiGraphics p_281667_, ToastComponent p_281321_, long p_281779_) {
      if (this.f_94807_) {
         this.f_94806_ = p_281779_;
         this.f_94807_ = false;
      }

      if (this.f_94805_.isEmpty()) {
         return Toast.Visibility.HIDE;
      } else {
         p_281667_.m_280218_(f_94893_, 0, 0, 0, 32, this.m_7828_(), this.m_94899_());
         p_281667_.m_280614_(p_281321_.m_94929_().f_91062_, f_94803_, 30, 7, -11534256, false);
         p_281667_.m_280614_(p_281321_.m_94929_().f_91062_, f_94804_, 30, 18, -16777216, false);
         Recipe<?> recipe = this.f_94805_.get((int)((double)p_281779_ / Math.max(1.0D, 5000.0D * p_281321_.m_264542_() / (double)this.f_94805_.size()) % (double)this.f_94805_.size()));
         ItemStack itemstack = recipe.m_8042_();
         p_281667_.m_280168_().m_85836_();
         p_281667_.m_280168_().m_85841_(0.6F, 0.6F, 1.0F);
         p_281667_.m_280203_(itemstack, 3, 3);
         p_281667_.m_280168_().m_85849_();
         p_281667_.m_280203_(recipe.m_8043_(p_281321_.m_94929_().f_91073_.m_9598_()), 8, 8);
         return (double)(p_281779_ - this.f_94806_) >= 5000.0D * p_281321_.m_264542_() ? Toast.Visibility.HIDE : Toast.Visibility.SHOW;
      }
   }

   private void m_94811_(Recipe<?> p_94812_) {
      this.f_94805_.add(p_94812_);
      this.f_94807_ = true;
   }

   public static void m_94817_(ToastComponent p_94818_, Recipe<?> p_94819_) {
      RecipeToast recipetoast = p_94818_.m_94926_(RecipeToast.class, f_94894_);
      if (recipetoast == null) {
         p_94818_.m_94922_(new RecipeToast(p_94819_));
      } else {
         recipetoast.m_94811_(p_94819_);
      }

   }
}