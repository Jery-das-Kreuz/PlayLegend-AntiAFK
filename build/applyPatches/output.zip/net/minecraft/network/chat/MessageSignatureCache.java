package net.minecraft.network.chat;

import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import org.jetbrains.annotations.VisibleForTesting;

public class MessageSignatureCache {
   public static final int f_252441_ = -1;
   private static final int f_243760_ = 128;
   private final MessageSignature[] f_243958_;

   public MessageSignatureCache(int p_250894_) {
      this.f_243958_ = new MessageSignature[p_250894_];
   }

   public static MessageSignatureCache m_246587_() {
      return new MessageSignatureCache(128);
   }

   public int m_252764_(MessageSignature p_254157_) {
      for(int i = 0; i < this.f_243958_.length; ++i) {
         if (p_254157_.equals(this.f_243958_[i])) {
            return i;
         }
      }

      return -1;
   }

   @Nullable
   public MessageSignature m_252914_(int p_253967_) {
      return this.f_243958_[p_253967_];
   }

   public void m_247208_(PlayerChatMessage p_248938_) {
      List<MessageSignature> list = p_248938_.f_240885_().f_240868_().f_241630_();
      ArrayDeque<MessageSignature> arraydeque = new ArrayDeque<>(list.size() + 1);
      arraydeque.addAll(list);
      MessageSignature messagesignature = p_248938_.f_244279_();
      if (messagesignature != null) {
         arraydeque.add(messagesignature);
      }

      this.m_245729_(arraydeque);
   }

   @VisibleForTesting
   void m_246417_(List<MessageSignature> p_248560_) {
      this.m_245729_(new ArrayDeque<>(p_248560_));
   }

   private void m_245729_(ArrayDeque<MessageSignature> p_251419_) {
      Set<MessageSignature> set = new ObjectOpenHashSet<>(p_251419_);

      for(int i = 0; !p_251419_.isEmpty() && i < this.f_243958_.length; ++i) {
         MessageSignature messagesignature = this.f_243958_[i];
         this.f_243958_[i] = p_251419_.removeLast();
         if (messagesignature != null && !set.contains(messagesignature)) {
            p_251419_.addFirst(messagesignature);
         }
      }

   }
}