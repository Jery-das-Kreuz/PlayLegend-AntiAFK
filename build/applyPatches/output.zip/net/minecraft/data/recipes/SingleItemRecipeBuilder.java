package net.minecraft.data.recipes;

import com.google.gson.JsonObject;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementRewards;
import net.minecraft.advancements.CriterionTriggerInstance;
import net.minecraft.advancements.RequirementsStrategy;
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.ItemLike;

public class SingleItemRecipeBuilder implements RecipeBuilder {
   private final RecipeCategory f_244239_;
   private final Item f_126302_;
   private final Ingredient f_126303_;
   private final int f_126304_;
   private final Advancement.Builder f_126305_ = Advancement.Builder.m_285878_();
   @Nullable
   private String f_126306_;
   private final RecipeSerializer<?> f_126307_;

   public SingleItemRecipeBuilder(RecipeCategory p_251425_, RecipeSerializer<?> p_249762_, Ingredient p_251221_, ItemLike p_251302_, int p_250964_) {
      this.f_244239_ = p_251425_;
      this.f_126307_ = p_249762_;
      this.f_126302_ = p_251302_.m_5456_();
      this.f_126303_ = p_251221_;
      this.f_126304_ = p_250964_;
   }

   public static SingleItemRecipeBuilder m_245264_(Ingredient p_248596_, RecipeCategory p_250503_, ItemLike p_250269_) {
      return new SingleItemRecipeBuilder(p_250503_, RecipeSerializer.f_44095_, p_248596_, p_250269_, 1);
   }

   public static SingleItemRecipeBuilder m_246944_(Ingredient p_251375_, RecipeCategory p_248984_, ItemLike p_250105_, int p_249506_) {
      return new SingleItemRecipeBuilder(p_248984_, RecipeSerializer.f_44095_, p_251375_, p_250105_, p_249506_);
   }

   public SingleItemRecipeBuilder m_126132_(String p_176810_, CriterionTriggerInstance p_176811_) {
      this.f_126305_.m_138386_(p_176810_, p_176811_);
      return this;
   }

   public SingleItemRecipeBuilder m_126145_(@Nullable String p_176808_) {
      this.f_126306_ = p_176808_;
      return this;
   }

   public Item m_142372_() {
      return this.f_126302_;
   }

   public void m_126140_(Consumer<FinishedRecipe> p_126327_, ResourceLocation p_126328_) {
      this.m_126329_(p_126328_);
      this.f_126305_.m_138396_(f_236353_).m_138386_("has_the_recipe", RecipeUnlockedTrigger.m_63728_(p_126328_)).m_138354_(AdvancementRewards.Builder.m_10009_(p_126328_)).m_138360_(RequirementsStrategy.f_15979_);
      p_126327_.accept(new SingleItemRecipeBuilder.Result(p_126328_, this.f_126307_, this.f_126306_ == null ? "" : this.f_126306_, this.f_126303_, this.f_126302_, this.f_126304_, this.f_126305_, p_126328_.m_246208_("recipes/" + this.f_244239_.m_247710_() + "/")));
   }

   private void m_126329_(ResourceLocation p_126330_) {
      if (this.f_126305_.m_138405_().isEmpty()) {
         throw new IllegalStateException("No way of obtaining recipe " + p_126330_);
      }
   }

   public static class Result implements FinishedRecipe {
      private final ResourceLocation f_126331_;
      private final String f_126332_;
      private final Ingredient f_126333_;
      private final Item f_126334_;
      private final int f_126335_;
      private final Advancement.Builder f_126336_;
      private final ResourceLocation f_126337_;
      private final RecipeSerializer<?> f_126338_;

      public Result(ResourceLocation p_126340_, RecipeSerializer<?> p_126341_, String p_126342_, Ingredient p_126343_, Item p_126344_, int p_126345_, Advancement.Builder p_126346_, ResourceLocation p_126347_) {
         this.f_126331_ = p_126340_;
         this.f_126338_ = p_126341_;
         this.f_126332_ = p_126342_;
         this.f_126333_ = p_126343_;
         this.f_126334_ = p_126344_;
         this.f_126335_ = p_126345_;
         this.f_126336_ = p_126346_;
         this.f_126337_ = p_126347_;
      }

      public void m_7917_(JsonObject p_126349_) {
         if (!this.f_126332_.isEmpty()) {
            p_126349_.addProperty("group", this.f_126332_);
         }

         p_126349_.add("ingredient", this.f_126333_.m_43942_());
         p_126349_.addProperty("result", BuiltInRegistries.f_257033_.m_7981_(this.f_126334_).toString());
         p_126349_.addProperty("count", this.f_126335_);
      }

      public ResourceLocation m_6445_() {
         return this.f_126331_;
      }

      public RecipeSerializer<?> m_6637_() {
         return this.f_126338_;
      }

      @Nullable
      public JsonObject m_5860_() {
         return this.f_126336_.m_138400_();
      }

      @Nullable
      public ResourceLocation m_6448_() {
         return this.f_126337_;
      }
   }
}