package net.minecraft.data.worldgen.features;

import java.util.List;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderSet;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.LakeFeature;
import net.minecraft.world.level.levelgen.feature.configurations.BlockStateConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.DiskConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SpringConfiguration;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.RuleBasedBlockStateProvider;
import net.minecraft.world.level.material.Fluids;

public class MiscOverworldFeatures {
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195010_ = FeatureUtils.m_255087_("ice_spike");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195011_ = FeatureUtils.m_255087_("ice_patch");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195012_ = FeatureUtils.m_255087_("forest_rock");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195013_ = FeatureUtils.m_255087_("iceberg_packed");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195014_ = FeatureUtils.m_255087_("iceberg_blue");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195015_ = FeatureUtils.m_255087_("blue_ice");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195016_ = FeatureUtils.m_255087_("lake_lava");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195017_ = FeatureUtils.m_255087_("disk_clay");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195018_ = FeatureUtils.m_255087_("disk_gravel");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195019_ = FeatureUtils.m_255087_("disk_sand");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195020_ = FeatureUtils.m_255087_("freeze_top_layer");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_236760_ = FeatureUtils.m_255087_("disk_grass");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195021_ = FeatureUtils.m_255087_("bonus_chest");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195022_ = FeatureUtils.m_255087_("void_start_platform");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195023_ = FeatureUtils.m_255087_("desert_well");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195024_ = FeatureUtils.m_255087_("spring_lava_overworld");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195025_ = FeatureUtils.m_255087_("spring_lava_frozen");
   public static final ResourceKey<ConfiguredFeature<?, ?>> f_195026_ = FeatureUtils.m_255087_("spring_water");

   public static void m_254957_(BootstapContext<ConfiguredFeature<?, ?>> p_256346_) {
      FeatureUtils.m_255061_(p_256346_, f_195010_, Feature.f_65773_);
      FeatureUtils.m_254977_(p_256346_, f_195011_, Feature.f_65781_, new DiskConfiguration(RuleBasedBlockStateProvider.m_225936_(Blocks.f_50354_), BlockPredicate.m_198311_(List.of(Blocks.f_50493_, Blocks.f_50440_, Blocks.f_50599_, Blocks.f_50546_, Blocks.f_50195_, Blocks.f_50127_, Blocks.f_50126_)), UniformInt.m_146622_(2, 3), 1));
      FeatureUtils.m_254977_(p_256346_, f_195012_, Feature.f_65780_, new BlockStateConfiguration(Blocks.f_50079_.m_49966_()));
      FeatureUtils.m_254977_(p_256346_, f_195013_, Feature.f_65779_, new BlockStateConfiguration(Blocks.f_50354_.m_49966_()));
      FeatureUtils.m_254977_(p_256346_, f_195014_, Feature.f_65779_, new BlockStateConfiguration(Blocks.f_50568_.m_49966_()));
      FeatureUtils.m_255061_(p_256346_, f_195015_, Feature.f_65778_);
      FeatureUtils.m_254977_(p_256346_, f_195016_, Feature.f_65783_, new LakeFeature.Configuration(BlockStateProvider.m_191384_(Blocks.f_49991_.m_49966_()), BlockStateProvider.m_191384_(Blocks.f_50069_.m_49966_())));
      FeatureUtils.m_254977_(p_256346_, f_195017_, Feature.f_65781_, new DiskConfiguration(RuleBasedBlockStateProvider.m_225936_(Blocks.f_50129_), BlockPredicate.m_198311_(List.of(Blocks.f_50493_, Blocks.f_50129_)), UniformInt.m_146622_(2, 3), 1));
      FeatureUtils.m_254977_(p_256346_, f_195018_, Feature.f_65781_, new DiskConfiguration(RuleBasedBlockStateProvider.m_225936_(Blocks.f_49994_), BlockPredicate.m_198311_(List.of(Blocks.f_50493_, Blocks.f_50440_)), UniformInt.m_146622_(2, 5), 2));
      FeatureUtils.m_254977_(p_256346_, f_195019_, Feature.f_65781_, new DiskConfiguration(new RuleBasedBlockStateProvider(BlockStateProvider.m_191382_(Blocks.f_49992_), List.of(new RuleBasedBlockStateProvider.Rule(BlockPredicate.m_224774_(Direction.DOWN.m_122436_(), Blocks.f_50016_), BlockStateProvider.m_191382_(Blocks.f_50062_)))), BlockPredicate.m_198311_(List.of(Blocks.f_50493_, Blocks.f_50440_)), UniformInt.m_146622_(2, 6), 2));
      FeatureUtils.m_255061_(p_256346_, f_195020_, Feature.f_65775_);
      FeatureUtils.m_254977_(p_256346_, f_236760_, Feature.f_65781_, new DiskConfiguration(new RuleBasedBlockStateProvider(BlockStateProvider.m_191382_(Blocks.f_50493_), List.of(new RuleBasedBlockStateProvider.Rule(BlockPredicate.m_190402_(BlockPredicate.m_190420_(BlockPredicate.m_190423_(Direction.UP.m_122436_()), BlockPredicate.m_224777_(Direction.UP.m_122436_(), Fluids.f_76193_))), BlockStateProvider.m_191382_(Blocks.f_50440_)))), BlockPredicate.m_198311_(List.of(Blocks.f_50493_, Blocks.f_220864_)), UniformInt.m_146622_(2, 6), 2));
      FeatureUtils.m_255061_(p_256346_, f_195021_, Feature.f_65751_);
      FeatureUtils.m_255061_(p_256346_, f_195022_, Feature.f_65768_);
      FeatureUtils.m_255061_(p_256346_, f_195023_, Feature.f_65769_);
      FeatureUtils.m_254977_(p_256346_, f_195024_, Feature.f_65765_, new SpringConfiguration(Fluids.f_76195_.m_76145_(), true, 4, 1, HolderSet.m_205806_(Block::m_204297_, Blocks.f_50069_, Blocks.f_50122_, Blocks.f_50228_, Blocks.f_50334_, Blocks.f_152550_, Blocks.f_152496_, Blocks.f_152497_, Blocks.f_50493_)));
      FeatureUtils.m_254977_(p_256346_, f_195025_, Feature.f_65765_, new SpringConfiguration(Fluids.f_76195_.m_76145_(), true, 4, 1, HolderSet.m_205806_(Block::m_204297_, Blocks.f_50127_, Blocks.f_152499_, Blocks.f_50354_)));
      FeatureUtils.m_254977_(p_256346_, f_195026_, Feature.f_65765_, new SpringConfiguration(Fluids.f_76193_.m_76145_(), true, 4, 1, HolderSet.m_205806_(Block::m_204297_, Blocks.f_50069_, Blocks.f_50122_, Blocks.f_50228_, Blocks.f_50334_, Blocks.f_152550_, Blocks.f_152496_, Blocks.f_152497_, Blocks.f_50493_, Blocks.f_50127_, Blocks.f_152499_, Blocks.f_50354_)));
   }
}