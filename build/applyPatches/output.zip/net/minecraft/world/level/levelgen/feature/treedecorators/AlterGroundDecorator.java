package net.minecraft.world.level.levelgen.feature.treedecorators;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

public class AlterGroundDecorator extends TreeDecorator {
   public static final Codec<AlterGroundDecorator> f_69302_ = BlockStateProvider.f_68747_.fieldOf("provider").xmap(AlterGroundDecorator::new, (p_69327_) -> {
      return p_69327_.f_69303_;
   }).codec();
   private final BlockStateProvider f_69303_;

   public AlterGroundDecorator(BlockStateProvider p_69306_) {
      this.f_69303_ = p_69306_;
   }

   protected TreeDecoratorType<?> m_6663_() {
      return TreeDecoratorType.f_70046_;
   }

   public void m_214187_(TreeDecorator.Context p_225969_) {
      List<BlockPos> list = Lists.newArrayList();
      List<BlockPos> list1 = p_225969_.m_226070_();
      List<BlockPos> list2 = p_225969_.m_226068_();
      if (list1.isEmpty()) {
         list.addAll(list2);
      } else if (!list2.isEmpty() && list1.get(0).m_123342_() == list2.get(0).m_123342_()) {
         list.addAll(list2);
         list.addAll(list1);
      } else {
         list.addAll(list1);
      }

      if (!list.isEmpty()) {
         int i = list.get(0).m_123342_();
         list.stream().filter((p_69310_) -> {
            return p_69310_.m_123342_() == i;
         }).forEach((p_225978_) -> {
            this.m_225970_(p_225969_, p_225978_.m_122024_().m_122012_());
            this.m_225970_(p_225969_, p_225978_.m_122030_(2).m_122012_());
            this.m_225970_(p_225969_, p_225978_.m_122024_().m_122020_(2));
            this.m_225970_(p_225969_, p_225978_.m_122030_(2).m_122020_(2));

            for(int j = 0; j < 5; ++j) {
               int k = p_225969_.m_226067_().m_188503_(64);
               int l = k % 8;
               int i1 = k / 8;
               if (l == 0 || l == 7 || i1 == 0 || i1 == 7) {
                  this.m_225970_(p_225969_, p_225978_.m_7918_(-3 + l, 0, -3 + i1));
               }
            }

         });
      }
   }

   private void m_225970_(TreeDecorator.Context p_225971_, BlockPos p_225972_) {
      for(int i = -2; i <= 2; ++i) {
         for(int j = -2; j <= 2; ++j) {
            if (Math.abs(i) != 2 || Math.abs(j) != 2) {
               this.m_225973_(p_225971_, p_225972_.m_7918_(i, 0, j));
            }
         }
      }

   }

   private void m_225973_(TreeDecorator.Context p_225974_, BlockPos p_225975_) {
      for(int i = 2; i >= -3; --i) {
         BlockPos blockpos = p_225975_.m_6630_(i);
         if (Feature.m_65788_(p_225974_.m_226058_(), blockpos)) {
            p_225974_.m_226061_(blockpos, this.f_69303_.m_213972_(p_225974_.m_226067_(), p_225975_));
            break;
         }

         if (!p_225974_.m_226059_(blockpos) && i < 0) {
            break;
         }
      }

   }
}