package net.minecraft.client.gui.components;

import com.google.common.collect.ImmutableList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface MultiLineLabel {
   MultiLineLabel f_94331_ = new MultiLineLabel() {
      public int m_6276_(GuiGraphics p_283287_, int p_94383_, int p_94384_) {
         return p_94384_;
      }

      public int m_6514_(GuiGraphics p_283384_, int p_94395_, int p_94396_, int p_94397_, int p_94398_) {
         return p_94396_;
      }

      public int m_6508_(GuiGraphics p_283077_, int p_94379_, int p_94380_, int p_282157_, int p_282742_) {
         return p_94380_;
      }

      public int m_6516_(GuiGraphics p_283645_, int p_94389_, int p_94390_, int p_94391_, int p_94392_) {
         return p_94390_;
      }

      public void m_207298_(GuiGraphics p_283208_, int p_210825_, int p_210826_, int p_210827_, int p_210828_, int p_210829_) {
      }

      public int m_5770_() {
         return 0;
      }

      public int m_214161_() {
         return 0;
      }
   };

   static MultiLineLabel m_94341_(Font p_94342_, FormattedText p_94343_, int p_94344_) {
      return m_94361_(p_94342_, p_94342_.m_92923_(p_94343_, p_94344_).stream().map((p_94374_) -> {
         return new MultiLineLabel.TextWithWidth(p_94374_, p_94342_.m_92724_(p_94374_));
      }).collect(ImmutableList.toImmutableList()));
   }

   static MultiLineLabel m_94345_(Font p_94346_, FormattedText p_94347_, int p_94348_, int p_94349_) {
      return m_94361_(p_94346_, p_94346_.m_92923_(p_94347_, p_94348_).stream().limit((long)p_94349_).map((p_94371_) -> {
         return new MultiLineLabel.TextWithWidth(p_94371_, p_94346_.m_92724_(p_94371_));
      }).collect(ImmutableList.toImmutableList()));
   }

   static MultiLineLabel m_94350_(Font p_94351_, Component... p_94352_) {
      return m_94361_(p_94351_, Arrays.stream(p_94352_).map(Component::m_7532_).map((p_94360_) -> {
         return new MultiLineLabel.TextWithWidth(p_94360_, p_94351_.m_92724_(p_94360_));
      }).collect(ImmutableList.toImmutableList()));
   }

   static MultiLineLabel m_169036_(Font p_169037_, List<Component> p_169038_) {
      return m_94361_(p_169037_, p_169038_.stream().map(Component::m_7532_).map((p_169035_) -> {
         return new MultiLineLabel.TextWithWidth(p_169035_, p_169037_.m_92724_(p_169035_));
      }).collect(ImmutableList.toImmutableList()));
   }

   static MultiLineLabel m_94361_(final Font p_94362_, final List<MultiLineLabel.TextWithWidth> p_94363_) {
      return p_94363_.isEmpty() ? f_94331_ : new MultiLineLabel() {
         private final int f_232519_ = p_94363_.stream().mapToInt((p_232527_) -> {
            return p_232527_.f_94428_;
         }).max().orElse(0);

         public int m_6276_(GuiGraphics p_283492_, int p_283184_, int p_282078_) {
            return this.m_6514_(p_283492_, p_283184_, p_282078_, 9, 16777215);
         }

         public int m_6514_(GuiGraphics p_281603_, int p_281267_, int p_281819_, int p_281545_, int p_282780_) {
            int i = p_281819_;

            for(MultiLineLabel.TextWithWidth multilinelabel$textwithwidth : p_94363_) {
               p_281603_.m_280648_(p_94362_, multilinelabel$textwithwidth.f_94427_, p_281267_ - multilinelabel$textwithwidth.f_94428_ / 2, i, p_282780_);
               i += p_281545_;
            }

            return i;
         }

         public int m_6508_(GuiGraphics p_282318_, int p_283665_, int p_283416_, int p_281919_, int p_281686_) {
            int i = p_283416_;

            for(MultiLineLabel.TextWithWidth multilinelabel$textwithwidth : p_94363_) {
               p_282318_.m_280648_(p_94362_, multilinelabel$textwithwidth.f_94427_, p_283665_, i, p_281686_);
               i += p_281919_;
            }

            return i;
         }

         public int m_6516_(GuiGraphics p_281782_, int p_282841_, int p_283554_, int p_282768_, int p_283499_) {
            int i = p_283554_;

            for(MultiLineLabel.TextWithWidth multilinelabel$textwithwidth : p_94363_) {
               p_281782_.m_280649_(p_94362_, multilinelabel$textwithwidth.f_94427_, p_282841_, i, p_283499_, false);
               i += p_282768_;
            }

            return i;
         }

         public void m_207298_(GuiGraphics p_281633_, int p_210832_, int p_210833_, int p_210834_, int p_210835_, int p_210836_) {
            int i = p_94363_.stream().mapToInt((p_232524_) -> {
               return p_232524_.f_94428_;
            }).max().orElse(0);
            if (i > 0) {
               p_281633_.m_280509_(p_210832_ - i / 2 - p_210835_, p_210833_ - p_210835_, p_210832_ + i / 2 + p_210835_, p_210833_ + p_94363_.size() * p_210834_ + p_210835_, p_210836_);
            }

         }

         public int m_5770_() {
            return p_94363_.size();
         }

         public int m_214161_() {
            return this.f_232519_;
         }
      };
   }

   int m_6276_(GuiGraphics p_281749_, int p_94334_, int p_94335_);

   int m_6514_(GuiGraphics p_281785_, int p_94337_, int p_94338_, int p_94339_, int p_94340_);

   int m_6508_(GuiGraphics p_282655_, int p_94365_, int p_94366_, int p_94367_, int p_94368_);

   int m_6516_(GuiGraphics p_281982_, int p_94354_, int p_94355_, int p_94356_, int p_94357_);

   void m_207298_(GuiGraphics p_282120_, int p_210818_, int p_210819_, int p_210820_, int p_210821_, int p_210822_);

   int m_5770_();

   int m_214161_();

   @OnlyIn(Dist.CLIENT)
   public static class TextWithWidth {
      final FormattedCharSequence f_94427_;
      final int f_94428_;

      TextWithWidth(FormattedCharSequence p_94430_, int p_94431_) {
         this.f_94427_ = p_94430_;
         this.f_94428_ = p_94431_;
      }
   }
}