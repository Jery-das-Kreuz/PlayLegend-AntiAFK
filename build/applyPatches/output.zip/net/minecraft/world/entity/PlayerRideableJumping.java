package net.minecraft.world.entity;

public interface PlayerRideableJumping extends PlayerRideable {
   void m_7888_(int p_21696_);

   boolean m_7132_();

   void m_7199_(int p_21695_);

   void m_8012_();

   default int m_245614_() {
      return 0;
   }
}